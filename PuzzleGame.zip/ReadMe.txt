 Image Puzzle Game 🧩

This is a web-based interactive image puzzle game where users can select the puzzle size (from 2x2 to 5x5), shuffle pieces, and solve the puzzle within a time limit.

## Features
- Choose puzzle size (2x2, 3x3, 4x4, 5x5)
- Drag and drop puzzle pieces to rearrange
- Timer that counts down based on puzzle size
- Congratulatory message when puzzle is solved correctly
- Responsive design for a neat user experience

## Technologies Used
- HTML5 for structure
- CSS3 for styling
- JavaScript for game logic and interactivity

## How to Run
1. Clone or download this repository.
2. Open `index.html` in your favorite web browser.
3. Select the desired puzzle size.
4. Click "Start Timer & Shuffle Puzzle" to begin.
5. Drag the pieces to solve the puzzle before the timer runs out.


Enjoy the game! 🎉

