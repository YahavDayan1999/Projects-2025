const container = document.getElementById('puzzle-container');
const startBtn = document.getElementById('start-btn');
const changeImageBtn = document.getElementById('change-image-btn');
const timerEl = document.getElementById('timer');
const sizeSelect = document.getElementById('size-select');
const messageEl = document.getElementById('message');

let images = [
    'https://picsum.photos/id/1015/500/500',
    'https://picsum.photos/id/1019/500/500',
    'https://picsum.photos/id/1024/500/500',
    'https://picsum.photos/id/1035/500/500',
];

let currentImageIndex = 0;
let gridSize = parseInt(sizeSelect.value);
let pieces = [];
let currentOrder = [];
let dragSrcIndex = null;
let timer;
let timeLeft;
let gameStarted = false;

function createPieces(size) {
    container.innerHTML = '';
    messageEl.textContent = '';
    gridSize = size;
    container.style.gridTemplateColumns = `repeat(${size}, 1fr)`;
    container.style.gridTemplateRows = `repeat(${size}, 1fr)`;

    pieces = [];
    currentOrder = [];

    let index = 0;
    for (let row = 0; row < size; row++) {
        for (let col = 0; col < size; col++) {
            const piece = document.createElement('div');
            piece.classList.add('piece');

            const pieceSize = 500;
            const bgX = -col * (pieceSize / size);
            const bgY = -row * (pieceSize / size);
            piece.style.backgroundImage = `url('${images[currentImageIndex]}')`;
            piece.style.backgroundPosition = `${bgX}px ${bgY}px`;
            piece.style.width = `${pieceSize / size}px`;
            piece.style.height = `${pieceSize / size}px`;
            piece.style.backgroundSize = `${pieceSize}px ${pieceSize}px`;

            piece.setAttribute('draggable', 'true');

            piece.dataset.correctIndex = index;

            piece.addEventListener('dragstart', dragStart);
            piece.addEventListener('dragover', dragOver);
            piece.addEventListener('drop', drop);
            piece.addEventListener('dragend', dragEnd);

            container.appendChild(piece);
            pieces.push(piece);
            currentOrder.push(index);

            index++;
        }
    }
}

function dragStart(e) {
    if(!gameStarted) return;  // prevent drag if game not started
    dragSrcIndex = Array.from(container.children).indexOf(e.target);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragSrcIndex);
    e.target.classList.add('dragging');
}

function dragOver(e) {
    if(!gameStarted) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
}

function drop(e) {
    if(!gameStarted) return;
    e.preventDefault();
    const dragDstIndex = Array.from(container.children).indexOf(e.target);

    if (dragSrcIndex === null || dragDstIndex === dragSrcIndex) return;

    swapPieces(dragSrcIndex, dragDstIndex);
    updateDOMOrder();

    if (checkWin()) {
        clearInterval(timer);
        gameStarted = false;
        messageEl.style.color = 'green';
        messageEl.textContent = '🎉 Congratulations! You solved the puzzle in time!';
    }
}

function dragEnd(e) {
    e.target.classList.remove('dragging');
}

function swapPieces(index1, index2) {
    const temp = currentOrder[index1];
    currentOrder[index1] = currentOrder[index2];
    currentOrder[index2] = temp;
}

function updateDOMOrder() {
    const newOrder = [];
    for (let i = 0; i < currentOrder.length; i++) {
        newOrder.push(pieces[currentOrder[i]]);
    }
    container.innerHTML = '';
    newOrder.forEach(piece => container.appendChild(piece));
}

function checkWin() {
    for (let i = 0; i < currentOrder.length; i++) {
        if (currentOrder[i] !== i) return false;
    }
    return true;
}

function shufflePieces() {
    for (let i = currentOrder.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [currentOrder[i], currentOrder[j]] = [currentOrder[j], currentOrder[i]];
    }
    updateDOMOrder();
}

function startTimer() {
    clearInterval(timer);
    timeLeft = gridSize * gridSize * 6; // 10 seconds per piece
    timerEl.textContent = `⏱ Time: ${timeLeft} seconds`;
    timer = setInterval(() => {
        timeLeft--;
        timerEl.textContent = `⏱ Time: ${timeLeft} seconds`;
        if (timeLeft <= 0) {
            clearInterval(timer);
            gameStarted = false;
            messageEl.style.color = 'red';
            messageEl.textContent = '⏳ Time is up! Please try again.';
            createPieces(gridSize); // reset puzzle
        }
    }, 1000);
}

startBtn.addEventListener('click', () => {
    gridSize = parseInt(sizeSelect.value);
    createPieces(gridSize);
    shufflePieces();
    startTimer();
    gameStarted = true;
    messageEl.style.color = 'green';
    messageEl.textContent = '';
});

changeImageBtn.addEventListener('click', () => {
    if (gameStarted) {
        alert('Please finish the current game before changing the image.');
        return;
    }
    currentImageIndex = (currentImageIndex + 1) % images.length;
    createPieces(gridSize);
});

// Create puzzle on initial load without starting timer
createPieces(gridSize);

