#include "company.h"

#include <corecrt.h>
#include <malloc.h>
#include <search.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "act.h"
#include "array.h"
#include "constants.h"
#include "reservation.h"
#include "show.h"
#include "theater.h"
#include "tui.h"

Company *Company_init(const char name[NAME_SIZE])
{
    Company *company = malloc(sizeof(Company));
    if (company == NULL)
        return NULL;

    strncpy_s(company->name, sizeof(company->name), name, _TRUNCATE);
    company->acts               = calloc(INITIAL_CAPACITY, sizeof(Act));
    company->actsLength         = 0;
    company->theaters           = calloc(INITIAL_CAPACITY, sizeof(Theater));
    company->theatersLength     = 0;
    company->shows              = calloc(INITIAL_CAPACITY, sizeof(Show));
    company->showsLength        = 0;
    company->reservations       = calloc(INITIAL_CAPACITY, sizeof(Reservation));
    company->reservationsLength = 0;

    return company;
}

static void _freeObject(void (*freeier)(void *), void *object)
{
    freeier(object);
}

void Company_free(Company *company)
{
    Array_map(company->acts, company->actsLength, sizeof(Act), _freeObject, Act_freeInternal);
    Array_map(company->shows, company->showsLength, sizeof(Show), _freeObject, Show_freeInternal);
    Array_map(
            company->reservations,
            company->reservationsLength,
            sizeof(Reservation),
            _freeObject,
            Reservation_freeInternal
    );

    free(company->acts);
    free(company->theaters);
    free(company->shows);
    free(company->reservations);

    free(company);
}

static bool _textRead(
        FILE *file,
        const char *title,
        Company *company,
        void **array,
        size_t *length,
        const size_t itemWidth,
        void *(reader)(FILE *, Company *)
)
{
    char fmt[128];
    sprintf_s(fmt, sizeof(fmt), "\n%ss: %%zu\n------------------------------\n", title);

    size_t finalLength;
    if (fscanf_s(file, fmt, &finalLength) != 1)
        return false;

    for (size_t i = 0; i < finalLength; i++)
    {
        void *obj = reader(file, company);
        if (obj == NULL)
        {
            Company_free(company);
            return false;
        }
        Array_append(array, length, itemWidth, obj);
        free(obj);
    }

    return true;
}

Company *Company_textRead(FILE *file)
{
    char name[NAME_SIZE];
    if (fscanf_s(file, "Company: %[^\n]\n", name, NAME_LENGTH) != 1)
        return NULL;

    Company *company = Company_init(name);

    if (_textRead(file, "Act", company, (void **)&company->acts, &company->actsLength, sizeof(Act), Act_textRead) &&
        _textRead(
                file,
                "Theater",
                company,
                (void **)&company->theaters,
                &company->theatersLength,
                sizeof(Theater),
                Theater_textRead
        ) &&
        _textRead(
                file, "Show", company, (void **)&company->shows, &company->showsLength, sizeof(Show), Show_textRead
        ) &&
        _textRead(
                file,
                "Reservation",
                company,
                (void **)&company->reservations,
                &company->reservationsLength,
                sizeof(Reservation),
                Reservation_textRead
        ))
    {
        Array_map(company->shows, company->showsLength, sizeof(Show), Show_populateReservations, company);
        return company;
    }

    Company_free(company);
    return NULL;
}

void _textWrite(
        FILE *file,
        char *title,
        const void *array,
        const size_t length,
        const size_t itemWidth,
        void (*writer)(FILE *f, void *item)
)
{
    fprintf_s(file, "\n%ss: %zu\n------------------------------\n", title, length);
    Array_map(array, length, itemWidth, (void (*)(void *, void *))writer, file);
}

void Company_textWrite(FILE *file, const Company *company)
{
    fprintf_s(file, "Company: %s\n", company->name);
    _textWrite(file, "Act", company->acts, company->actsLength, sizeof(Act), Act_textWrite);
    _textWrite(file, "Theater", company->theaters, company->theatersLength, sizeof(Theater), Theater_textWrite);
    _textWrite(file, "Show", company->shows, company->showsLength, sizeof(Show), Show_textWrite);
    _textWrite(
            file,
            "Reservation",
            company->reservations,
            company->reservationsLength,
            sizeof(Reservation),
            Reservation_textWrite
    );
}

static bool _binaryRead(
        FILE *file,
        Company *company,
        void **array,
        size_t *length,
        const size_t itemWidth,
        void *(reader)(FILE *, Company *)
)
{
    size_t finalLength;
    if (fread_s(&finalLength, sizeof(finalLength), sizeof(finalLength), 1, file) != 1)
        return false;

    for (size_t i = 0; i < finalLength; i++)
    {
        void *obj = reader(file, company);
        if (obj == NULL)
        {
            Company_free(company);
            return false;
        }
        Array_append(array, length, itemWidth, obj);
        free(obj);
    }

    return true;
}

Company *Company_binaryRead(FILE *file)
{
    char name[NAME_SIZE];
    if (fread_s(name, NAME_SIZE, sizeof(char), NAME_LENGTH, file) != NAME_LENGTH)
        return NULL;

    Company *company = Company_init(name);

    if (_binaryRead(file, company, (void **)&company->acts, &company->actsLength, sizeof(Act), Act_binaryRead) &&
        _binaryRead(
                file,
                company,
                (void **)&company->theaters,
                &company->theatersLength,
                sizeof(Theater),
                Theater_binaryRead
        ) &&
        _binaryRead(file, company, (void **)&company->shows, &company->showsLength, sizeof(Show), Show_binaryRead) &&
        _binaryRead(
                file,
                company,
                (void **)&company->reservations,
                &company->reservationsLength,
                sizeof(Reservation),
                Reservation_binaryRead
        ))
    {
        Array_map(company->shows, company->showsLength, sizeof(Show), Show_populateReservations, company);
        return company;
    }

    Company_free(company);
    return NULL;
}

void _binaryWrite(
        FILE *file, const void *array, const size_t length, const size_t itemWidth, void (*writer)(FILE *f, void *item)
)
{
    fwrite(&length, sizeof(length), 1, file);
    Array_map(array, length, itemWidth, (void (*)(void *, void *))writer, file);
}

void Company_binaryWrite(FILE *file, const Company *company)
{
    fwrite(&company->name, sizeof(char), NAME_LENGTH, file);
    _binaryWrite(file, company->acts, company->actsLength, sizeof(Act), Act_binaryWrite);
    _binaryWrite(file, company->theaters, company->theatersLength, sizeof(Theater), Theater_binaryWrite);
    _binaryWrite(file, company->shows, company->showsLength, sizeof(Show), Show_binaryWrite);
    _binaryWrite(
            file, company->reservations, company->reservationsLength, sizeof(Reservation), Reservation_binaryWrite
    );
}

static void findMostProfitable(const Company *company)
{
    if (company->showsLength == 0)
    {
        printError("There are no Reservations");
        return;
    }

    size_t mostProfitable = 0;
    int maxProfit         = 0;

    for (size_t i = 0; i < company->showsLength; ++i)
    {
        const Show *current = &company->shows[i];
        if (current != NULL)
        {
            const int profit = Show_calculateProfit(current);
            if (profit > maxProfit)
            {
                mostProfitable = i;
                maxProfit      = profit;
            }
        }
    }

    printf_s("\n Most profitable is Show #%zu: %d$\n", mostProfitable, maxProfit);
}

static Show **_pointersToShows(Show *array, const size_t length)
{
    Show **pointerArray       = calloc(length, sizeof(void *));
    size_t pointerArrayLength = 0;

    for (size_t i = 0; i < length; i++)
    {
        Show *item = &array[i];
        Array_append((void **)&pointerArray, &pointerArrayLength, sizeof(Show *), &item);
    }

    return pointerArray;
}

static void sortShowsBy(const Company *company, int (*compareItems)(const void *, const void *))
{
    Show **array = _pointersToShows(company->shows, company->showsLength);

    qsort(array, company->showsLength, sizeof(Show *), compareItems);

    Show_printTableHeaders(company->showsLength);
    for (size_t i = 0; i < company->showsLength; i++)
        Show_printTableRow(NULL, array[i]);

    free(array);
}

static void searchShowsBy(const Company *company, Show **(*searcher)(const Show **array, size_t length))
{
    Show **array = _pointersToShows(company->shows, company->showsLength);

    Show **found = searcher(array, company->showsLength);
    if (found == NULL)
        printError("There is no matching Show");
    else
        printf_s("\n  Show #%zu\n", (*found)->index);

    free(array);
}

typedef enum
{
    CMO_Exit = 0,
    CMO_CreateAct,
    CMO_CreateTheater,
    CMO_CreateShow,
    CMO_CreateReservation,
    CMO_ListActs,
    CMO_ListReservations,
    CMO_ListTheaters,
    CMO_ListShows,
    CMO_ShowsByStart,
    CMO_ShowsByEnd,
    CMO_ShowsByDuration,
    CMO_ShowWithStart,
    CMO_ShowsWithEnd,
    CMO_ShowWithDuration,
    CMO_CalculateProfit,
    CMO_MostProfitable,
    CMO_noptions
} CompanyMenuOption;

static const char *companyMenuOptionNames[] = {
        "Exit",
        "Create Act",
        "Create Theater",
        "Create Show",
        "Create Reservation",
        "List Acts",
        "List Reservations",
        "List Theaters",
        "List Shows",
        "Shows sorted by Start DateTime",
        "Shows sorted by End DateTime",
        "Shows sorted by Duration",
        "Search show by Start DateTime",
        "Search show by End DateTime",
        "Search show by Duration",
        "Calculate profit",
        "Find most profitable Show"
};

void Company_executeMenu(Company *company)
{
    while (true)
    {
        system("cls");
        printHeader("Company Menu");
        printCentered("Logged into Company: %s\n", company->name);

        for (size_t i = 0; i < CMO_noptions; i++)
            printf("%3zu) %s.\n", i, companyMenuOptionNames[i]);

        switch (getInputSize("\nOption", CMO_noptions - 1))
        {
            case CMO_Exit:
                return;
            case CMO_CreateAct:
                Act_input(company);
                break;
            case CMO_ListActs:
                Act_printTableHeaders(company->actsLength);
                Array_map(company->acts, company->actsLength, sizeof(Act), Act_printTableRow, NULL);
                break;
            case CMO_CreateReservation:
                Reservation_input(company);
                break;
            case CMO_ListReservations:
                Reservation_printTableHeaders(company->reservationsLength);
                Array_map(
                        company->reservations,
                        company->reservationsLength,
                        sizeof(Reservation),
                        Reservation_printTableRow,
                        NULL
                );
                break;
            case CMO_CreateShow:
                Show_input(company);
                break;
            case CMO_ListShows:
                Show_printTableHeaders(company->showsLength);
                Array_map(company->shows, company->showsLength, sizeof(Show), Show_printTableRow, NULL);
                break;
            case CMO_ShowsByStart:
                sortShowsBy(company, Show_differenceOfStartTimes);
                break;
            case CMO_ShowWithStart:
                searchShowsBy(company, Show_searchByStartTime);
                break;
            case CMO_ShowsByEnd:
                sortShowsBy(company, Show_differenceOfEndTimes);
                break;
            case CMO_ShowsWithEnd:
                searchShowsBy(company, Show_searchByEndTime);
                break;
            case CMO_ShowsByDuration:
                sortShowsBy(company, Show_differenceOfDurations);
                break;
            case CMO_ShowWithDuration:
                searchShowsBy(company, Show_searchByDuration);
                break;
            case CMO_CreateTheater:
                Theater_input(company);
                break;
            case CMO_ListTheaters:
                Theater_printTableHeaders(company->theatersLength);
                Array_map(company->theaters, company->theatersLength, sizeof(Theater), Theater_printTableRow, NULL);
                break;
            case CMO_CalculateProfit:
                printf_s(
                        "\n Total profit: %d$\n",
                        Array_sum(
                                company->shows,
                                company->showsLength,
                                sizeof(Show),
                                (int (*)(const void *))Show_calculateProfit
                        )
                );
                break;
            case CMO_MostProfitable:
                findMostProfitable(company);
                break;
            default:
                printError("Unknown option");
                break;
        }

        pauseAndContinue();
    }
}
