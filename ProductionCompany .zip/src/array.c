#include "array.h"

#include <malloc.h>
#include <memory.h>

void Array_append(void **array, size_t *length, const size_t itemWidth, const void *item)
{
    *array = realloc(*array, (*length + 1) * itemWidth);
    memcpy_s((char *)*array + *length * itemWidth, itemWidth, item, itemWidth);
    *length = *length + 1;
}

void Array_map(
        const void *array, const size_t length, const size_t itemWidth, void (*const func)(void *, void *), void *ctx
)
{
    for (size_t i = 0; i < length; i++)
        func(ctx, (char *)array + i * itemWidth);
}

int Array_sum(const void *array, const size_t length, const size_t itemWidth, int (*const valueOf)(const void *))
{
    int sum = 0;
    for (size_t i = 0; i < length; i++)
        sum += valueOf((char *)array + i * itemWidth);
    return sum;
}
