#include "theater.h"

#include <constants.h>
#include <corecrt.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "array.h"
#include "company.h"
#include "tui.h"

Theater *Theater_init(const size_t index, const char name[NAME_SIZE], const int hourlyRent, const SeatLayout seating)
{
    Theater *theater = malloc(sizeof(Theater));
    if (theater == NULL)
        return NULL;

    strncpy_s(theater->name, sizeof(theater->name), name, _TRUNCATE);

    theater->index      = index;
    theater->hourlyRent = hourlyRent;
    theater->seating    = seating;

    return theater;
}

void Theater_printTableHeaders(const size_t length)
{
    printTableHeader(
            length,
            "Theater",
            "Index "
            "| %-31s "
            "| Hourly Rent "
            "| Reg Seats "
            "| VIP Seats",
            "Name"
    );
}

void Theater_printTableRow(void *_, const Theater *theater)
{
    char reg[16];
    sprintf_s(reg, sizeof(reg), "%3zu x %-3zu", theater->seating.reg.rows, theater->seating.reg.seatsPerRow);

    char vip[16];
    sprintf_s(vip, sizeof(vip), "%3zu x %-3zu", theater->seating.vip.rows, theater->seating.vip.seatsPerRow);

    printTableRow(
            " %4zu "
            "| %-31s "
            "| %10lld$ "
            "| %9s "
            "| %9s",
            theater->index,
            theater->name,
            theater->hourlyRent,
            reg,
            vip
    );
}

void Theater_textWrite(FILE *file, const Theater *theater)
{
    fprintf_s(
            file,
            "\nIndex: %zu\n"
            "Name: %s\n"
            "Rent: %d\n"
            "Regular: %zu x %zu\n"
            "VIP: %zu x %zu\n",
            theater->index,
            theater->name,
            theater->hourlyRent,
            theater->seating.reg.rows,
            theater->seating.reg.seatsPerRow,
            theater->seating.vip.rows,
            theater->seating.vip.seatsPerRow
    );
}

Theater *Theater_textRead(FILE *file, const Company *company)
{
    size_t index;
    char name[NAME_SIZE];
    int hourlyRent;
    SeatLayout seating;
    const int converted = fscanf_s(
            file,
            "\nIndex: %zu\n"
            "Name: %[^\n]\n"
            "Rent: %d\n"
            "Regular: %zu x %zu\n"
            "VIP: %zu x %zu\n",
            &index,
            name,
            NAME_LENGTH,
            &hourlyRent,
            &seating.reg.rows,
            &seating.reg.seatsPerRow,
            &seating.vip.rows,
            &seating.vip.seatsPerRow
    );
    if (converted != 7)
        return NULL;

    return Theater_init(index, name, hourlyRent, seating);
}

void Theater_binaryWrite(FILE *file, const Theater *theater)
{
    fwrite(&theater->index, sizeof(theater->index), 1, file);
    fwrite(&theater->name, sizeof(char), NAME_LENGTH, file);
    fwrite(&theater->hourlyRent, sizeof(int), 1, file);
    fwrite(&theater->seating, sizeof(SeatLayout), 1, file);
}

Theater *Theater_binaryRead(FILE *file, const Company *company)
{
    size_t index;
    if (fread_s(&index, sizeof(index), sizeof(index), 1, file) != 1)
        return NULL;

    char name[NAME_SIZE];
    if (fread_s(name, NAME_SIZE, sizeof(char), NAME_LENGTH, file) != NAME_LENGTH)
        return NULL;

    int hourlyRent;
    if (fread_s(&hourlyRent, sizeof(int), sizeof(int), 1, file) != 1)
        return NULL;

    SeatLayout seating;
    if (fread_s(&seating, sizeof(SeatLayout), sizeof(SeatLayout), 1, file) != 1)
        return NULL;

    return Theater_init(index, name, hourlyRent, seating);
}

int Theater_differenceOfNames(const Theater *theater1, const Theater *theater2)
{
    return strncmp(theater1->name, theater2->name, NAME_LENGTH);
}

void Theater_input(Company *company)
{
    printf("Creating new Theater at index %zu:\n", company->theatersLength);

    char *name                  = getInputString("Name", NAME_LENGTH);
    const int hourlyRent        = (int)getInputSize("Hourly Rent", 0);
    const size_t regRows        = getInputSize("Regular Rows", 0);
    const size_t regSeatsPerRow = getInputSize("Regular Seats per Row", 0);
    const size_t vipRows        = getInputSize("VIP Rows", 0);
    const size_t vipSeatsPerRow = getInputSize("VIP Seats per Row", 0);

    Theater *theater = Theater_init(
            company->theatersLength,
            name,
            hourlyRent,
            (SeatLayout
            ){.reg = {.rows = regRows, .seatsPerRow = regSeatsPerRow},
              .vip = {.rows = vipRows, .seatsPerRow = vipSeatsPerRow}}
    );

    Array_append(&company->theaters, &company->theatersLength, sizeof(Theater), theater);
    free(name);
    free(theater);
}
