#include "tui.h"

#include <corecrt.h>
#include <errno.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <vadefs.h>

#define TUI_MAX_WIDTH (150)

static void printLineCapped(const char pre, const char chr, const char suf, const size_t width)
{
    char buffer[TUI_MAX_WIDTH];

    buffer[0] = pre;

    // Set the entire buffer to `chr`.
    for (int i = 0; i < width - 2; ++i)
        buffer[i] = chr;

    buffer[width - 2] = suf;
    buffer[width - 1] = '\0';

    puts(buffer);
}

static void printLine(const char chr, const size_t width)
{
    printLineCapped(chr, chr, chr, width);
}

void printCentered(const char *format, ...)
{
    char buffer[TUI_MAX_WIDTH];
    buffer[TUI_MAX_WIDTH - 1] = '\0';

    va_list args = NULL;
    va_start(args, format);
    const int textWidth = vsnprintf_s(buffer, TUI_MAX_WIDTH - 1, _TRUNCATE, format, args);
    va_end(args);

    printf("%*s%s", (TUI_MAX_WIDTH - textWidth) / 2, " ", buffer);
}

void printHeader(const char *format, ...)
{
    char buffer[TUI_MAX_WIDTH];
    va_list args = NULL;
    va_start(args, format);
    vsnprintf_s(buffer, TUI_MAX_WIDTH - 1, _TRUNCATE, format, args);
    va_end(args);

    printCentered("%s\n", buffer);
    printLine('-', TUI_MAX_WIDTH);
}

static void printTableSeperator(const size_t width)
{
    printLineCapped('+', '-', '+', width);
}

void printTableHeader(const size_t rows, const char *title, const char *columnsFormat, ...)
{
    char applied[TUI_MAX_WIDTH];
    va_list args = NULL;
    va_start(args, columnsFormat);
    vsnprintf_s(applied, sizeof(applied) - 1, _TRUNCATE, columnsFormat, args);
    va_end(args);

    char columns[TUI_MAX_WIDTH];
    int width = _snprintf_s(columns, sizeof(columns) - 1, _TRUNCATE, "| %s |", applied);
    width++;

    printTableSeperator(width);
    printf("| %-3llu Rows of %-*s |\n", rows, width - 17, title);
    printTableSeperator(width);
    puts(columns);
    printLine('=', width);
}

void printTableRow(const char *columnsFormat, ...)
{
    char formatted[TUI_MAX_WIDTH];
    va_list args = NULL;
    va_start(args, columnsFormat);
    vsnprintf_s(formatted, sizeof(formatted) - 1, _TRUNCATE, columnsFormat, args);
    va_end(args);

    char bordered[TUI_MAX_WIDTH];
    const int width = _snprintf_s(bordered, sizeof(bordered) - 1, _TRUNCATE, "| %s |", formatted);

    puts(bordered);
    printTableSeperator(width + 1);
}

void printError(const char *format, ...)
{
    char buffer[TUI_MAX_WIDTH];
    va_list args = NULL;
    va_start(args, format);
    vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, format, args);
    va_end(args);

    printf("\n! Error: %s !\n\n", buffer);
}

void printSystemError(const char *format, ...)
{
    char error[64];
    strerror_s(error, sizeof(error), errno);

    char buffer[TUI_MAX_WIDTH];
    va_list args = NULL;
    va_start(args, format);
    vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, format, args);
    va_end(args);

    printf("\n! System Error: %s: %s !\n\n", buffer, error);
}

static void _clearInputBuffer()
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
    {
    }
}

void pauseAndContinue()
{
    printf("\nPress Enter to continue...");
    _clearInputBuffer();
}

time_t getInputTime(const char *prompt)
{
    do
    {
        char *input = getInputString(prompt, 0);

        int year, month, day, hour, minute;
        const int converted = sscanf_s(input, "%d-%d-%d %d:%d", &year, &month, &day, &hour, &minute);
        free(input);

        if (converted != 5)
        {
            printError("Invalid time format. Please use 'YYYY-MM-DD HH:MM'.");
            continue;
        }

        struct tm time = {
                .tm_year  = year - 1900, // Years since 1900
                .tm_mon   = month - 1,   // Months since January (0-11)
                .tm_mday  = day,         // Day of the month (1-31)
                .tm_hour  = hour,        // Hours (0-23)
                .tm_min   = minute,      // Minutes (0-59)
                .tm_sec   = 0,
                .tm_isdst = -1, // Let mktime determine daylight saving time
        };

        const time_t timestamp = mktime(&time);

        if (timestamp == -1)
            printError("Invalid time value. Please ensure the time is valid.");
        else
            return timestamp;
    } while (true);
}

static char *_getline()
{
    char *input        = NULL;
    size_t inputLength = 0;
    size_t bufferSize  = 32;

    while (true)
    {
        // Expand input buffer to the new possible length.
        input = realloc(input, bufferSize);
        if (input == NULL)
            return NULL;

        // Read from the characther we have already read,
        // until the end of the now-longer buffer.
        fgets(input + inputLength, (int)(bufferSize - inputLength), stdin);

        // If we read until the \n we can null-terminate the string and return it.
        inputLength = strlen(input);
        if (inputLength > 0 && input[inputLength - 1] == '\n')
        {
            input[inputLength - 1] = '\0';
            break;
        }

        // Otherwise we will try again next iteration with a longer buffer.
        bufferSize *= 2;
    }

    return input;
}

static size_t _getInputSize(const char *prompt, const size_t maximum)
{
    char *input = getInputString(prompt, 0);

    char *endptr;
    _set_errno(0);
    const size_t nmbr = strtoull(input, &endptr, 10);

    const bool convertedSuccessfuly = *endptr == '\0';
    free(input);

    if (errno)
        printSystemError("Could not read value");
    else if (!convertedSuccessfuly)
        printError("Must enter a valid positive integer");
    else if (maximum != 0 && nmbr > maximum)
        printError("Must be no more than %zu", maximum);
    else
        return nmbr;

    return -1;
}

size_t getInputSize(const char *prompt, const size_t maximum)
{
    size_t input = _getInputSize(prompt, maximum);
    while (input == -1)
        input = _getInputSize("  (Try again)", maximum);

    return input;
}

char *_getInputString(const char *prompt, const size_t maxLength)
{
    printf("%s: ", prompt);
    char *string = _getline();

    while (*string == '\0')
    {
        free(string);
        printf("%s: ", prompt);
        string = _getline();
    }

    if (maxLength != 0 && strlen(string) > maxLength)
    {
        printError("Too long, up to %zu charcters allowed", maxLength);
        free(string);
        return NULL;
    }

    return string;
}

char *getInputString(const char *prompt, const size_t maxLength)
{
    char *string = _getInputString(prompt, maxLength);
    while (string == NULL)
        string = _getInputString("  (Try again)", maxLength);

    return string;
}
