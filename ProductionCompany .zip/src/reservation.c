#include "reservation.h"

#include <list.h>
#include <malloc.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "array.h"
#include "company.h"
#include "tui.h"

Reservation *Reservation_init(const size_t index, Show *show)
{
    Reservation *reservation = malloc(sizeof(Reservation));
    if (reservation == NULL)
        return NULL;

    reservation->index      = index;
    reservation->show       = show;
    reservation->seatRanges = List_init();

    return reservation;
}

static void _freeSeatRange(void **_, SeatRange *seatRange)
{
    free(seatRange);
}

void Reservation_freeInternal(const Reservation *reservation)
{
    List_map(reservation->seatRanges, _freeSeatRange, NULL);
    List_free(reservation->seatRanges);
}

void Reservation_freeAll(Reservation *reservation)
{
    Reservation_freeInternal(reservation);
    free(reservation);
}

int Reservation_calculateProfit(const Reservation **reservation)
{
    int hourlyProfit = 0;

    const Node *node = (*reservation)->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;

        const int seats = (int)range->lastSeat - (int)range->firstSeat + 1;
        if (range->row < (*reservation)->show->theater->seating.vip.rows)
        {
            // VIP seats.
            hourlyProfit += seats * (*reservation)->show->act->hourlyTicketPrices.vip;
        }
        else
        {
            // Regular seats.
            hourlyProfit += seats * (*reservation)->show->act->hourlyTicketPrices.reg;
        }

        node = node->next;
    }

    const int showDurationHours = ((int)(*reservation)->show->end - (int)(*reservation)->show->start) / 3600;

    return hourlyProfit * showDurationHours;
}

void Reservation_printTableHeaders(const size_t length)
{
    printTableHeader(
            length,
            "Reservation",
            "Index "
            "| (idx) %-31s    %-31s ",
            "Show",
            ""
    );
}

void Reservation_printTableRow(void *_, const Reservation *reservation)
{
    printTableRow(
            " %4zu "
            "| %4zu  %31s at %-31s ",
            reservation->index,
            reservation->show->index,
            reservation->show->act->name,
            reservation->show->theater->name
    );
}

void Reservation_textWrite(FILE *file, const Reservation *reservation)
{
    fprintf_s(
            file,
            "\nIndex: %zu\n"
            "Show Index: %zu\n"
            "Seat Ranges: %zu\n",
            reservation->index,
            reservation->show->index,
            reservation->seatRanges->length
    );

    const Node *node = reservation->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;
        fprintf_s(file, "\t%zu, %zu-%zu\n", range->row, range->firstSeat, range->lastSeat);
        node = node->next;
    }
}

Reservation *Reservation_textRead(FILE *file, const Company *company)
{
    size_t index, showIndex, seatRangesLength;
    int converted = fscanf_s(
            file,
            "\nIndex: %zu\n"
            "Show Index: %zu\n"
            "Seat Ranges: %zu\n",
            &index,
            &showIndex,
            &seatRangesLength
    );
    if (converted != 3)
        return NULL;

    Reservation *reservation = Reservation_init(index, &company->shows[showIndex]);
    for (size_t i = 0; i < seatRangesLength; i++)
    {
        SeatRange *range = malloc(sizeof(SeatRange));
        if (range == NULL)
            return NULL;
        converted = fscanf_s(file, "\t%zu, %zu-%zu\n", &range->row, &range->firstSeat, &range->lastSeat);
        if (converted != 3)
        {
            free(range);
            Reservation_freeAll(reservation);
            return NULL;
        }
        List_insert(reservation->seatRanges, range);
    }

    return reservation;
}

void Reservation_binaryWrite(FILE *file, const Reservation *reservation)
{
    fwrite(&reservation->index, sizeof(reservation->index), 1, file);
    fwrite(&reservation->show->index, sizeof(reservation->show->index), 1, file);
    fwrite(&reservation->seatRanges->length, sizeof(reservation->seatRanges->length), 1, file);

    const Node *node = reservation->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;
        fwrite(range, sizeof(SeatRange), 1, file);
        node = node->next;
    }
}

Reservation *Reservation_binaryRead(FILE *file, const Company *company)
{
    size_t index;
    if (fread_s(&index, sizeof(index), sizeof(index), 1, file) != 1)
        return NULL;

    size_t showIndex, seatRangesLength;
    if (fread_s(&showIndex, sizeof(showIndex), sizeof(showIndex), 1, file) != 1)
        return NULL;

    if (fread_s(&seatRangesLength, sizeof(seatRangesLength), sizeof(seatRangesLength), 1, file) != 1)
        return NULL;

    Show *show               = &company->shows[showIndex];
    Reservation *reservation = Reservation_init(index, show);
    for (size_t i = 0; i < seatRangesLength; i++)
    {
        SeatRange *range = malloc(sizeof(SeatRange));
        if (range == NULL)
            return NULL;
        if (fread_s(range, sizeof(SeatRange), sizeof(SeatRange), 1, file) != 1)
        {
            free(range);
            Reservation_freeAll(reservation);
            return NULL;
        }
        List_insert(reservation->seatRanges, range);
    }

    return reservation;
}

static bool isSeatInReservation(const size_t row, const size_t seat, const Reservation *reservation)
{
    const Node *node = reservation->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;
        if (range->row == row && range->firstSeat <= seat && seat <= range->lastSeat)
            return true;
        node = node->next;
    }
    return false;
}

static bool isReserved(const size_t row, const size_t seat, const Show *show)
{
    // For each other reservation to the same show...
    for (size_t i = 0; i < show->reservationsLength; ++i)
        if (isSeatInReservation(row, seat, show->reservations[i]))
            return true;
    return false;
}

static void printSeating(const Reservation *reservation)
{
    const Theater *theater = reservation->show->theater;

    // For each row in the theater...
    for (size_t row = 0; row < theater->seating.vip.rows + theater->seating.reg.rows; row++)
    {
        printf("%2zu ", row + 1);
        if (row < theater->seating.vip.rows)
        {
            printf("VIP ");
        }
        // For each seat in the row...
        for (size_t seat = 0; seat < (row < theater->seating.vip.rows ? theater->seating.vip.seatsPerRow
                                                                      : theater->seating.reg.seatsPerRow);
             seat++)
        {

            if (isSeatInReservation(row, seat, reservation))
            {
                printf("[xx] ");
            }
            else if (isReserved(row, seat, reservation->show))
            {
                printf("     ");
            }
            else
            {
                printf("[%2zu] ", seat + 1);
            }
        }
        puts("");
        if (row == theater->seating.vip.rows - 1)
        {
            puts("");
        }
    }
}

static void seatRangesBefore(const Reservation *reservation)
{
    // Print the seating layout and selected seats
    printSeating(reservation);

    const Show *show = reservation->show;

    // Print the ticket prices
    const int regPrice = show->act->hourlyTicketPrices.reg * ((int)show->end - (int)show->start) / 3600;
    printf("\nRegular Ticket Price: %d$\n", regPrice);

    const int vipPrice = show->act->hourlyTicketPrices.vip * ((int)show->end - (int)show->start) / 3600;
    printf("VIP Ticket Price: %d$\n", vipPrice);

    // Print the total cost of reserved tickets
    int totalCost    = 0;
    const Node *node = reservation->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;

        const int seats = (int)range->lastSeat - (int)range->firstSeat + 1;
        if (range->row < show->theater->seating.vip.rows)
            totalCost += seats * vipPrice;
        else
            totalCost += seats * regPrice;

        node = node->next;
    }

    printf("Total reservation price: %d$\n", totalCost);
}

static void inputSeatRange(const Reservation *reservation)
{
    const Theater *theater = reservation->show->theater;
    const size_t row       = -1 + getInputSize("Row", theater->seating.vip.rows + theater->seating.reg.rows);
    const size_t firstSeat = -1 + getInputSize(
                                          "First Seat",
                                          row < theater->seating.vip.rows ? theater->seating.vip.seatsPerRow
                                                                          : theater->seating.reg.seatsPerRow
                                  );
    const size_t lastSeat = -1 + getInputSize(
                                         "Last Seat",
                                         row < theater->seating.vip.rows ? theater->seating.vip.seatsPerRow
                                                                         : theater->seating.reg.seatsPerRow
                                 );

    if (firstSeat > lastSeat)
    {
        printError("First seat must be to the left of last seat");
        return;
    }

    // Check if the seat range is already reserved

    // For each seat range in that reservation...
    const Node *node = reservation->seatRanges->head;
    while (node != NULL)
    {
        const SeatRange *range = node->item;
        // If the range overlaps with the inputted range...
        if (range->row == row && max(range->firstSeat, firstSeat) <= min(range->lastSeat, lastSeat))
        {
            printError("The selected seat range overlaps with a previus one", reservation->index);
            return;
        }
        node = node->next;
    }

    // For each other reservetion to the same show...
    for (size_t i = 0; i < reservation->show->reservationsLength; ++i)
    {
        const Reservation *otherReservation = reservation->show->reservations[i];
        // For each seat range in that reservation...
        node = otherReservation->seatRanges->head;
        while (node != NULL)
        {
            const SeatRange *range = node->item;
            // If the range overlaps with the inputted range...
            if (range->row == row && max(range->firstSeat, firstSeat) <= min(range->lastSeat, lastSeat))
            {
                printError(
                        "The selected seat range overlaps with an existing Reservation %zu)", otherReservation->index
                );
                return;
            }
            node = node->next;
        }
    }

    SeatRange *seatRange = malloc(sizeof(SeatRange));
    if (seatRange == NULL)
        return;
    seatRange->row       = row;
    seatRange->firstSeat = firstSeat;
    seatRange->lastSeat  = lastSeat;

    List_insert(reservation->seatRanges, seatRange);
}

static void deleteSeatRange(const Reservation *reservation)
{
    if (reservation->seatRanges->length == 0)
    {
        printError("No ranges to delete");
        return;
    }

    if (reservation->seatRanges->length == 1)
    {
        puts("There is only one range, delete it?");
        char *str = getInputString("(Enter y/Y to delete)", 0);

        if (str[1] == '\0' && (str[0] == 'y' || str[0] == 'Y'))
            List_removeByIndex(reservation->seatRanges, 0, free);

        free(str);
        return;
    }

    const Node *node = reservation->seatRanges->head;
    size_t index     = 0;
    while (node != NULL)
    {
        const SeatRange *range = node->item;
        printf_s("%zu. Row %zu, seats %zu-%zu\n", index, range->row + 1, range->firstSeat + 1, range->lastSeat + 1);
        index++;
        node = node->next;
    }

    index = getInputSize("Range", reservation->seatRanges->length - 1);
    List_removeByIndex(reservation->seatRanges, index, free);
}

typedef enum
{
    RMO_Exit,
    RMO_Add,
    RMO_Delete,
    RMO_noptions
} ReservationMenuOption;

static const char *reservationMenuOptionNames[] = {"Exit", "Add range", "Delte Range"};

static void inputSeatRanges(const Reservation *reservation)
{
    while (true)
    {
        system("cls");
        printHeader("Select Seat Ranges");
        seatRangesBefore(reservation);

        for (size_t i = 0; i < RMO_noptions; i++)
            printf("%3zu) %s.\n", i, reservationMenuOptionNames[i]);

        switch (getInputSize("\nOption", RMO_noptions - 1))
        {
            case RMO_Exit:
                return;
            case RMO_Add:
                inputSeatRange(reservation);
                break;
            case RMO_Delete:
                deleteSeatRange(reservation);
                break;
            default:
                printError("Unknown option");
                break;
        }

        pauseAndContinue();
    }
}

void Reservation_input(Company *company)
{
    if (company->showsLength == 0) {
        printError("Can't create a reservertion because there are 0 shows");
        return;
    }

    printf_s("Creating new Reservation at index %zu:\n", company->reservationsLength);

    if (company->showsLength == 1)
    {
        puts("There is only one show, choosing it automaticaly");
        pauseAndContinue();
    }
    const size_t showIndex = company->showsLength == 1 ? 0 : getInputSize("Show (index)", company->showsLength - 1);
    Reservation *reservation = Reservation_init(company->reservationsLength, &company->shows[showIndex]);
    inputSeatRanges(reservation);

    Array_append(&company->reservations, &company->reservationsLength, sizeof(Reservation), reservation);
    free(reservation);
    Reservation *companyReservation = &company->reservations[company->reservationsLength - 1];
    Array_append(
            (void **)&companyReservation->show->reservations,
            &companyReservation->show->reservationsLength,
            sizeof(Reservation *),
            &companyReservation
    );
}
