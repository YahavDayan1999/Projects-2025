#include <constants.h>
#include <corecrt.h>
#include <malloc.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "company.h"
#include "tui.h"

static Company *_exampleCompany(const char *fname)
{
    FILE *file;
    fopen_s(&file, fname, "r");
    if (file == NULL)
        return NULL;

    Company *company = Company_textRead(file);

    fclose(file);
    return company;
}

static bool _getInputFilePath(char outFilePath[_MAX_PATH])
{
    char *path = getInputString("File path, .txt or .bin", _MAX_PATH);

    const char *extensionStart = strrchr(path, '.');
    if (extensionStart == NULL)
    {
        printError("Could not determine extention for '%s'", path);
        free(path);
        *outFilePath = '\0';
        return false;
    }

    bool isText;
    if (_strcmpi(extensionStart, ".txt") == 0)
        isText = true;
    else if (_strcmpi(extensionStart, ".bin") == 0)
        isText = false;
    else
    {
        printError("'%s' files are not supported, only '.txt' and '.bin'.", extensionStart);
        free(path);
        *outFilePath = '\0';
        return false;
    }

    strncpy_s(outFilePath, _MAX_PATH, path, _TRUNCATE);
    free(path);
    return isText;
}

static void _loadCompanyFromFile(Company **ctxCompany)
{
    char filePath[_MAX_PATH];
    const bool isText = _getInputFilePath(filePath);
    if (*filePath == '\0')
        return;

    FILE *file;
    fopen_s(&file, filePath, isText ? "r" : "rb");

    if (file == NULL)
    {
        printSystemError("Could not open file '%s'", filePath);
        return;
    }

    Company *loadedCompany = isText ? Company_textRead(file) : Company_binaryRead(file);

    if (loadedCompany == NULL)
    {
        printError("Contents of file are malformed near position %ld.", ftell(file) + 1);
        fclose(file);
        return;
    }

    fclose(file);

    if (*ctxCompany != NULL)
        Company_free(*ctxCompany);
    *ctxCompany = loadedCompany;

    printf("Company '%s' loaded successfully.\n", (*ctxCompany)->name);
}

static void _createNewCompany(Company **ctxCompany)
{
    char *name = getInputString("Company name", NAME_LENGTH);
    if (*ctxCompany != NULL)
        Company_free(*ctxCompany);
    *ctxCompany = Company_init(name);
    free(name);
    printf("Company '%s' created and loaded successfully.\n", (*ctxCompany)->name);
}

static void _saveLoadedCompanyToFile(const Company *company)
{
    if (company == NULL)
    {
        printError("No company is currently loaded. Please load or create a company first.");
        return;
    }

    char filePath[_MAX_PATH];
    const bool isText = _getInputFilePath(filePath);
    if (*filePath == '\0')
        return;

    FILE *file;
    fopen_s(&file, filePath, isText ? "w" : "wb");

    if (file == NULL)
    {
        printSystemError("Could not open file '%s'", filePath);
        return;
    }

    if (isText)
        Company_textWrite(file, company);
    else
        Company_binaryWrite(file, company);

    fclose(file);
    puts("Company saved successfully.");
}

static void _loginToLoadedCompany(Company *company)
{
    if (company == NULL)
    {
        printError("No company is currently loaded. Please load or create a company first.");
        return;
    }

    Company_executeMenu(company);
}

typedef enum
{
    MMO_Exit = 0,
    MMO_Load,
    MMO_Create,
    MMO_Save,
    MMO_Login,
    MMO_noptions
} MainMenuOption;

static const char *mainMenuOptionNames[] = {
        "Exit",
        "Load company from file",
        "Create new company",
        "Save loaded company to file",
        "Login to the loaded company"
};

void main()
{
    Company *company = _exampleCompany("example.txt");

    bool running = true;
    while (running)
    {
        system("cls");
        printHeader("Production Company System by Yahav Dayan & Omri Portal");

        if (company == NULL)
            printCentered("No company is loaded\n");
        else
            printCentered("Company: %s\n", company->name);

        for (size_t i = 0; i < MMO_noptions; i++)
            printf("%3zu) %s.\n", i, mainMenuOptionNames[i]);

        switch (getInputSize("\nOption", MMO_noptions - 1))
        {
            case MMO_Exit:
                running = false;
                break;
            case MMO_Load:
                _loadCompanyFromFile(&company);
                break;
            case MMO_Create:
                _createNewCompany(&company);
                break;
            case MMO_Save:
                _saveLoadedCompanyToFile(company);
                break;
            case MMO_Login:
                _loginToLoadedCompany(company);
                break;
            default:
                printError("Unknown option");
                break;
        }

        pauseAndContinue();
    }

    Company_free(company);
}
