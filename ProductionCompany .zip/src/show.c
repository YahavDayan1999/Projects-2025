#include "show.h"

#include <corecrt.h>
#include <malloc.h>
#include <search.h>
#include <stdio.h>
#include <time.h>

#include "array.h"
#include "company.h"
#include "reservation.h"
#include "tui.h"

Show *Show_init(const size_t index, Act *act, Theater *theater, const time_t start, const time_t end)
{
    Show *show = malloc(sizeof(Show));
    if (show == NULL)
        return NULL;

    show->index              = index;
    show->act                = act;
    show->theater            = theater;
    show->start              = start;
    show->end                = end;
    show->reservations       = calloc(INITIAL_CAPACITY, sizeof(Reservation *));
    show->reservationsLength = 0;

    return show;
}

void Show_freeInternal(const Show *show)
{
    free(show->reservations);
}

int Show_calculateProfit(const Show *show)
{
    const int hours = (int)(show->end - show->start) / 3600;

    const int ticketsProfit = Array_sum(
            show->reservations,
            show->reservationsLength,
            sizeof(Reservation *),
            (int (*)(const void *))Reservation_calculateProfit
    );

    const int salariesCost = hours * show->act->hourlySalary;
    const int rentCost     = hours * show->theater->hourlyRent;

    return ticketsProfit - salariesCost - rentCost;
}

#define STRFTIME "%Y-%m-%d %H:%M"

void Show_printTableHeaders(const size_t length)
{
    printTableHeader(
            length,
            "Show",
            "Index "
            "| (idx) %-31s "
            "| (idx) %-31s "
            "| Start DateTime   "
            "| End DateTime     "
            "| Reservations",
            "Act",
            "Theater"
    );
}

void Show_printTableRow(void *_, const Show *show)
{
    struct tm time;

    char startTime[32];
    localtime_s(&time, &show->start);
    strftime(startTime, sizeof(startTime), STRFTIME, &time);

    char endTime[32];
    localtime_s(&time, &show->end);
    strftime(endTime, sizeof(endTime), STRFTIME, &time);

    printTableRow(
            " %4zu "
            "| %4zu  %-31s "
            "| %4zu  %-31s "
            "| %s "
            "| %s "
            "| %12zu",
            show->index,
            show->act->index,
            show->act->name,
            show->theater->index,
            show->theater->name,
            startTime,
            endTime,
            show->reservationsLength
    );
}

void Show_textWrite(FILE *file, const Show *show)
{
    fprintf_s(
            file,
            "\nIndex: %zu\n"
            "Act Index: %zu\n"
            "Theater Index: %zu\n"
            "Start: %lld\n"
            "End: %lld\n",
            show->index,
            show->act->index,
            show->theater->index,
            show->start,
            show->end
    );
}

Show *Show_textRead(FILE *file, const Company *company)
{
    size_t index, actIndex, theaterIndex;
    time_t start, end;
    const int converted = fscanf_s(
            file,
            "\nIndex: %zu\n"
            "Act Index: %zu\n"
            "Theater Index: %zu\n"
            "Start: %lld\n"
            "End: %lld\n",
            &index,
            &actIndex,
            &theaterIndex,
            &start,
            &end
    );
    if (converted != 5)
        return NULL;

    return Show_init(index, &company->acts[actIndex], &company->theaters[theaterIndex], start, end);
}

void Show_binaryWrite(FILE *file, const Show *show)
{
    fwrite(&show->index, sizeof(show->index), 1, file);
    fwrite(&show->act->index, sizeof(show->act->index), 1, file);
    fwrite(&show->theater->index, sizeof(show->theater->index), 1, file);
    fwrite(&show->start, sizeof(show->start), 1, file);
    fwrite(&show->end, sizeof(show->end), 1, file);
}

Show *Show_binaryRead(FILE *file, const Company *company)
{
    size_t index;
    if (fread_s(&index, sizeof(index), sizeof(index), 1, file) != 1)
        return NULL;

    size_t actIndex;
    if (fread_s(&actIndex, sizeof(actIndex), sizeof(actIndex), 1, file) != 1)
        return NULL;

    size_t theaterIndex;
    if (fread_s(&theaterIndex, sizeof(theaterIndex), sizeof(theaterIndex), 1, file) != 1)
        return NULL;

    time_t start;
    if (fread_s(&start, sizeof(start), sizeof(start), 1, file) != 1)
        return NULL;

    time_t end;
    if (fread_s(&end, sizeof(end), sizeof(end), 1, file) != 1)
        return NULL;

    return Show_init(index, &company->acts[actIndex], &company->theaters[theaterIndex], start, end);
}

void Show_populateReservations(const Company *company, Show *show)
{
    for (size_t i = 0; i < company->reservationsLength; i++)
    {
        Reservation *reservation = &company->reservations[i];
        if (show->index == reservation->show->index)
            Array_append((void **)&show->reservations, &show->reservationsLength, sizeof(Reservation *), &reservation);
    }
}

int Show_differenceOfStartTimes(const Show **show1, const Show **show2)
{
    return (int)(*show1)->start - (int)(*show2)->start;
}

int Show_differenceOfEndTimes(const Show **show1, const Show **show2)
{
    return (int)(*show1)->end - (int)(*show2)->end;
}

int Show_differenceOfDurations(const Show **show1, const Show **show2)
{
    return (int)((*show1)->end - (*show1)->start) - (int)((*show2)->end - (*show2)->start);
}

void Show_input(Company *company)
{
    if (company->actsLength == 0) {
        printError("Can't create a show because there are 0 acts");
        return;
    }

    if (company->theatersLength == 0) {
        printError("Can't create a show because there are 0 theaters");
        return;
    }

    printf("Creating new Show at index %zu:\n", company->showsLength);

    if (company->actsLength == 1)
    {
        puts("There is only one act, choosing it automaticaly.");
        pauseAndContinue();
    }
    const size_t actIndex = company->actsLength == 1 ? 0 :getInputSize("Act (index)", company->actsLength - 1);
    if (company->theatersLength == 1)
    {
        puts("There is only one theater, choosing it automaticaly.");
        pauseAndContinue();
    }
    const size_t theaterIndex = company->theatersLength == 1 ? 0 : getInputSize("Theater (index)", company->theatersLength - 1);
    const time_t start = getInputTime("Start time");
    const time_t end   = getInputTime("End time");
    if (end <= start)
    {
        printError("End time must be after start time");
        return;
    }
    Show *show = Show_init(company->showsLength, &company->acts[actIndex], &company->theaters[theaterIndex], start, end);

    Array_append(&company->shows, &company->showsLength, sizeof(Show), show);
    free(show);
}

Show **Show_searchByStartTime(const Show **array, const size_t length)
{
    qsort(array, length, sizeof(Show *), Show_differenceOfStartTimes);

    Show target;
    target.start = getInputTime("Start Time");

    Show *key = &target;
    return bsearch(&key, array, length, sizeof(Show *), Show_differenceOfStartTimes);
}

Show **Show_searchByEndTime(const Show **array, const size_t length)
{
    qsort(array, length, sizeof(Show *), Show_differenceOfEndTimes);

    Show target;
    target.start = getInputTime("End Time");

    Show *key = &target;
    return bsearch(&key, array, length, sizeof(Show *), Show_differenceOfEndTimes);
}

Show **Show_searchByDuration(const Show **array, const size_t length)
{
    qsort(array, length, sizeof(Show *), Show_differenceOfDurations);

    Show target;
    const size_t durationMinutes = getInputSize("Duration (minutes)", 0);
    target.start                 = 0;
    target.end                   = durationMinutes * 60;

    Show *key = &target;
    return bsearch(&key, array, length, sizeof(Show *), Show_differenceOfDurations);
}
