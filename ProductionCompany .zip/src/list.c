#include "list.h"

#include <malloc.h>

List *List_init()
{
    List *list   = malloc(sizeof(List));
    if (list == NULL)
        return NULL;

    list->head   = NULL;
    list->length = 0;
    return list;
}

void List_free(List *list)
{
    Node *current = list->head;
    while (current != NULL)
    {
        Node *next = current->next;
        free(current);
        current = next;
    }

    free(list);
}

void List_insert(List *list, void *item)
{
    // Create new node
    Node *node = malloc(sizeof(Node));
    if (node == NULL)
        return;

    node->item = item;
    node->next = NULL;

    // Add it to the head of the list
    node->next = list->head;
    list->head = node;
    list->length++;
}

void List_removeByIndex(List *list, size_t index, void (*freeier)(void *item))
{
    Node *node, *prev = list->head;

    if (index == 0)
    {
        list->head = prev->next;
        node       = prev;
    }
    else
    {
        while (index-- > 1)
            prev = prev->next;

        node       = prev->next;
        prev->next = prev->next->next;
    }

    list->length--;
    freeier(node->item);
    free(node);
}

void _map(const Node *node, void (*const func)(void *ctx, void *item), void *ctx)
{
    if (node != NULL)
    {
        const Node *next = node->next;
        func(ctx, node->item);
        _map(next, func, ctx);
    }
}

void List_map(const List *list, void (*func)(void *ctx, void *item), void *ctx)
{
    _map(list->head, func, ctx);
}
