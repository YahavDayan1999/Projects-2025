#include "act.h"

#include <company.h>
#include <constants.h>
#include <corecrt.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "array.h"
#include "tui.h"

Act *Act_init(
        const size_t index,
        const char name[NAME_SIZE],
        const ActType type,
        const char *description,
        const int hourlySalary,
        const TicketPrices hourlyTicketPrices
)
{
    Act *act = malloc(sizeof(Act));
    if (act == NULL)
        return NULL;

    // Copy name.
    strncpy_s(act->name, sizeof(act->name), name, _TRUNCATE);

    // Allocate and copy description.
    const size_t descLength = min(strlen(description) + 1, MAX_ACT_DESCRIPTION_LENGTH);
    act->description        = malloc(descLength);
    if (act->description == NULL)
        return NULL;
    strncpy_s(act->description, descLength, description, _TRUNCATE);

    act->index              = index;
    act->type               = type;
    act->hourlySalary       = hourlySalary;
    act->hourlyTicketPrices = hourlyTicketPrices;

    return act;
}

void Act_freeInternal(const Act *act)
{
    free(act->description);
}

void Act_printTableHeaders(const size_t length)
{
    printTableHeader(
            length,
            "Act",
            "Index "
            "| %-31s "
            "| Act Type "
            "| %-31s "
            "| Hourly Salary "
            "| Reg Ticket "
            "| VIP Ticket",
            "Name",
            "Type",
            "Description"
    );
}

static const char *actTypeNames[] = {"Music", "Compedy", "Magic"};

void Act_printTableRow(void *_, const Act *act)
{
    printTableRow(
            "%4zu  "
            "| %-31s "
            "| %-8s "
            "| %-31.31s "
            "| %11d$ "
            "| %9d$ "
            "| %9d$ ",
            act->index,
            act->name,
            actTypeNames[act->type],
            act->description,
            act->hourlySalary,
            act->hourlyTicketPrices.reg,
            act->hourlyTicketPrices.vip
    );
}

void Act_textWrite(FILE *file, const Act *act)
{
    fprintf_s(
            file,
            "\nIndex: %zu\n"
            "Name: %s\n"
            "Type: %d\n"
            "Desc: %s\n"
            "Salary: %d\n"
            "Prices: %d, %d\n",
            act->index,
            act->name,
            act->type,
            act->description,
            act->hourlySalary,
            act->hourlyTicketPrices.reg,
            act->hourlyTicketPrices.vip
    );
}

Act *Act_textRead(FILE *file, const Company *company)
{
    size_t index;
    char name[NAME_SIZE];
    ActType type;
    char description[MAX_ACT_DESCRIPTION_LENGTH];
    int hourlySalary;
    TicketPrices hourlyTicketPrices;
    const int converted = fscanf_s(
            file,
            "\nIndex: %zu\n"
            "Name: %[^\n]\n"
            "Type: %d\n"
            "Desc: %[^\n]\n"
            "Salary: %d\n"
            "Prices: %d, %d\n",
            &index,
            name,
            NAME_LENGTH,
            &type,
            description,
            (unsigned)MAX_ACT_DESCRIPTION_LENGTH,
            &hourlySalary,
            &hourlyTicketPrices.reg,
            &hourlyTicketPrices.vip
    );
    if (converted != 7)
        return NULL;

    return Act_init(index, name, type, description, hourlySalary, hourlyTicketPrices);
}

void Act_binaryWrite(FILE *file, const Act *act)
{
    fwrite(&act->index, sizeof(act->index), 1, file);
    fwrite(&act->name, sizeof(char), NAME_LENGTH, file);

    unsigned long long compressedData = 0;
    compressedData |= (unsigned long long)act->type << (64 - ACT_TYPE_WIDTH);
    compressedData |= (unsigned long long)act->hourlySalary << (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH);
    compressedData |= (unsigned long long)act->hourlyTicketPrices.vip
                   << (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH - TICKET_PRRICE_WIDTH);
    compressedData |= (unsigned long long)act->hourlyTicketPrices.reg
                   << (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH - TICKET_PRRICE_WIDTH * 2);
    compressedData |= (unsigned long long)strlen(act->description);

    fwrite(&compressedData, sizeof(unsigned long long), 1, file);
    fwrite(act->description, sizeof(char), strlen(act->description), file);
}

Act *Act_binaryRead(FILE *file, const Company *company)
{
    size_t index;
    if (fread_s(&index, sizeof(index), sizeof(index), 1, file) != 1)
        return NULL;

    char name[NAME_SIZE];
    if (fread_s(name, NAME_SIZE, sizeof(char), NAME_LENGTH, file) != NAME_LENGTH)
        return NULL;

    unsigned long long compressedData;
    if (fread_s(&compressedData, sizeof(unsigned long long), sizeof(unsigned long long), 1, file) != 1)
        return NULL;

    const ActType type = (compressedData >> (64 - ACT_TYPE_WIDTH)) & ((1 << ACT_TYPE_WIDTH) - 1);
    const int hourlySalary =
            (compressedData >> (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH)) & ((1 << HOURLY_SALARY_WIDTH) - 1);
    const int vipTicketPrice = (compressedData >> (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH - TICKET_PRRICE_WIDTH)) &
                               ((1 << TICKET_PRRICE_WIDTH) - 1);
    const int regTicketPrice =
            (compressedData >> (64 - ACT_TYPE_WIDTH - HOURLY_SALARY_WIDTH - TICKET_PRRICE_WIDTH * 2)) &
            ((1 << TICKET_PRRICE_WIDTH) - 1);
    const size_t descriptionLength = compressedData & ((1 << DESCRIPTION_LENGTH_WIDTH) - 1);

    char description[MAX_ACT_DESCRIPTION_LENGTH];
    if (fread_s(description, descriptionLength, sizeof(char), descriptionLength, file) != descriptionLength)
        return NULL;
    description[descriptionLength] = '\0';

    return Act_init(
            index,
            name,
            type,
            description,
            hourlySalary,
            (TicketPrices){
                    regTicketPrice,
                    vipTicketPrice,
            }
    );
}

void Act_input(Company *company)
{
    printf("Creating new Act at index %zu:\n", company->actsLength);
    char *name = getInputString("Name", NAME_LENGTH);
    printf_s("0. Music\n1. Comedy\n2. Magic\n\n");
    const ActType type = getInputSize("ActType", 2);
    char *description  = getInputString("Description", MAX_ACT_DESCRIPTION_LENGTH);
    const int salary   = (int)getInputSize("Hourly Salary", MAX_ACT_SALARY);
    const int reg      = (int)getInputSize("Hourly Regular Seat Price", MAX_TICKET_PRICE);
    const int vip      = (int)getInputSize("Hourly VIP Seat Price", MAX_TICKET_PRICE);

    Act *act = Act_init(company->actsLength, name, type, description, salary, (TicketPrices){reg, vip});
    Array_append(&company->acts, &company->actsLength, sizeof(Act), act);

    free(name);
    free(description);
    free(act);
}
