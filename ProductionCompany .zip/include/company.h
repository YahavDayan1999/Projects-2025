#ifndef COMPANY_H
#define COMPANY_H

#include <stdio.h>

#include "constants.h"

// To avoid circular definitions
typedef struct Act Act;
typedef struct Reservation Reservation;
typedef struct Show Show;
typedef struct Theater Theater;

typedef struct
{
    char name[NAME_SIZE];
    Act *acts;
    size_t actsLength;
    Reservation *reservations;
    size_t reservationsLength;
    Show *shows;
    size_t showsLength;
    Theater *theaters;
    size_t theatersLength;
} Company;

Company *Company_init(const char name[NAME_SIZE]);
void Company_free(Company *company);
Company *Company_textRead(FILE *file);
void Company_textWrite(FILE *file, const Company *company);
Company *Company_binaryRead(FILE *file);
void Company_binaryWrite(FILE *file, const Company *company);
void Company_executeMenu(Company *company);

#endif
