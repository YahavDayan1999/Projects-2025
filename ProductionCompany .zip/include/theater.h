#ifndef THEATER_H
#define THEATER_H

#include <stdio.h>

#include "company.h"
#include "constants.h"

typedef struct
{
    size_t rows;
    size_t seatsPerRow;
} SeatGroupLayout;

typedef struct
{
    SeatGroupLayout reg;
    SeatGroupLayout vip;
} SeatLayout;

typedef struct Theater
{
    size_t index;
    char name[NAME_SIZE];
    int hourlyRent;
    SeatLayout seating;
} Theater;

Theater *Theater_init(size_t index, const char name[NAME_SIZE], int hourlyRent, SeatLayout seating);
void Theater_printTableHeaders(size_t length);
void Theater_printTableRow(void *_, const Theater *theater);
void Theater_textWrite(FILE *file, const Theater *theater);
Theater *Theater_textRead(FILE *file, const Company *company);
void Theater_binaryWrite(FILE *file, const Theater *theater);
Theater *Theater_binaryRead(FILE *file, const Company *company);
int Theater_differenceOfNames(const Theater *theater1, const Theater *theater2);
void Theater_input(Company *company);

#endif
