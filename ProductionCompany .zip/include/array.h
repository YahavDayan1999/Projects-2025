#ifndef ARRAY_H
#define ARRAY_H

#define INITIAL_CAPACITY (64)

void Array_append(void **array, size_t *length, size_t itemWidth, const void *item);
void Array_map(const void *array, size_t length, size_t itemWidth, void (*func)(void *, void *), void *ctx);
int Array_sum(const void *array, size_t length, size_t itemWidth, int (*valueOf)(const void *));

#endif
