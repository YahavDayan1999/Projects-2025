#ifndef CONSTANTS_H
#define CONSTANTS_H

// Common length of any name.
#define NAME_LENGTH 31
#define NAME_SIZE   (NAME_LENGTH + 1)

// Compute a maximun value for a field based on it's desired width.
#define MAX_BY_WIDTH(type, width) ((type)((1 << (width)) - 1))

#define ACT_TYPE_WIDTH     4
#define HOURLY_SALARY_WIDTH      24
#define TICKET_PRRICE_WIDTH      11
#define DESCRIPTION_LENGTH_WIDTH 14

#endif // CONSTANTS_H
