#ifndef SHOW_H
#define SHOW_H

#include "act.h"
#include "theater.h"

typedef struct Show
{
    size_t index;
    Act *act;
    Theater *theater;
    time_t start;
    time_t end;
    Reservation **reservations;
    size_t reservationsLength;
} Show;

Show *Show_init(size_t index, Act *act, Theater *theater, time_t start, time_t end);
void Show_freeInternal(const Show *show);
int Show_calculateProfit(const Show *show);
void Show_printTableHeaders(size_t length);
void Show_printTableRow(void *_, const Show *show);
void Show_textWrite(FILE *file, const Show *show);
Show *Show_textRead(FILE *file, const Company *company);
void Show_binaryWrite(FILE *file, const Show *show);
Show *Show_binaryRead(FILE *file, const Company *company);
void Show_populateReservations(const Company *company, Show *show);
void Show_input(Company *company);
Show **Show_searchByStartTime(const Show **array, size_t length);
Show **Show_searchByEndTime(const Show **array, size_t length);
Show **Show_searchByDuration(const Show **array, size_t length);
int Show_differenceOfStartTimes(const Show **show1, const Show **show2);
int Show_differenceOfEndTimes(const Show **show1, const Show **show2);
int Show_differenceOfDurations(const Show **show1, const Show **show2);

#endif
