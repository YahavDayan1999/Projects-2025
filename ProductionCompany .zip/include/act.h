#ifndef ACT_H
#define ACT_H

#include <stdio.h>

#include "company.h"
#include "constants.h"

#define MAX_ACT_DESCRIPTION_LENGTH MAX_BY_WIDTH(size_t, DESCRIPTION_LENGTH_WIDTH)
#define MAX_ACT_SALARY             MAX_BY_WIDTH(size_t, HOURLY_SALARY_WIDTH)
#define MAX_TICKET_PRICE           MAX_BY_WIDTH(int, TICKET_PRRICE_WIDTH)

typedef struct
{
    int reg;
    int vip;
} TicketPrices;

typedef enum
{
    AT_Music = 0,
    AT_Comedy,
    AT_Magic
} ActType;

typedef struct Act
{
    size_t index;
    char name[NAME_SIZE];
    ActType type;
    char *description;
    int hourlySalary;
    TicketPrices hourlyTicketPrices;
} Act;

Act *Act_init(
        size_t index,
        const char name[NAME_SIZE],
        ActType type,
        const char *description,
        int hourlySalary,
        TicketPrices hourlyTicketPrices
);
void Act_freeInternal(const Act *act);
void Act_printTableHeaders(size_t length);
void Act_printTableRow(void *_, const Act *act);
void Act_textWrite(FILE *file, const Act *act);
Act *Act_textRead(FILE *file, const Company *company);
void Act_binaryWrite(FILE *file, const Act *act);
Act *Act_binaryRead(FILE *file, const Company *company);
void Act_input(Company *company);

#endif // ACT_H
