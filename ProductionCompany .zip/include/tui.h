#ifndef TUI_H
#define TUI_H

#include <corecrt.h>

void printCentered(const char *format, ...);
void printHeader(const char *format, ...);
void printTableHeader(size_t rows, const char *title, const char *columnsFormat, ...);
void printTableRow(const char *columnsFormat, ...);
void printError(const char *format, ...);
void printSystemError(const char *format, ...);
void pauseAndContinue();
time_t getInputTime(const char *prompt);
size_t getInputSize(const char *prompt, size_t maximum);
char *getInputString(const char *prompt, size_t maxLength);

#endif
