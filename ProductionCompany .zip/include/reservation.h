#ifndef RESERVATION_H
#define RESERVATION_H

#include <stdio.h>

#include "list.h"
#include "show.h"

typedef struct
{
    size_t row;
    size_t firstSeat;
    size_t lastSeat;
} SeatRange;

typedef struct Reservation
{
    size_t index;
    Show *show;
    List *seatRanges;
} Reservation;

Reservation *Reservation_init(size_t index, Show *show);
void Reservation_freeInternal(const Reservation *reservation);
void Reservation_freeAll(Reservation *reservation);
int Reservation_calculateProfit(const Reservation **reservation);
void Reservation_printTableHeaders(size_t length);
void Reservation_printTableRow(void *_, const Reservation *reservation);
void Reservation_textWrite(FILE *file, const Reservation *reservation);
Reservation *Reservation_textRead(FILE *file, const Company *company);
void Reservation_binaryWrite(FILE *file, const Reservation *reservation);
Reservation *Reservation_binaryRead(FILE *file, const Company *company);
void Reservation_input(Company *company);

#endif
