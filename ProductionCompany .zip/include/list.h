#ifndef LIST_H
#define LIST_H

typedef struct node
{
    void *item;
    struct node *next;
} Node;

typedef struct
{
    Node *head;
    size_t length;
} List;

List *List_init();
void List_free(List *list);
void List_insert(List *list, void *item);
void List_removeByIndex(List *list, size_t index, void (*freeier)(void *item));
void List_map(const List *list, void (*func)(void *ctx, void *item), void *ctx);

#endif
